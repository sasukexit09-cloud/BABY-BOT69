<img
src="https://i.imgur.com/Mmo26FF.jpeg" alt="banner">

<h1 align="center">
  <img src="https://i.imgur.com/ZfuZrPc.jpeg" width="22px" alt="icon">
  Hinata Bot - Bot Chat Messenger
</h1>

<p align="center">
	<a href="https://nodejs.org/dist/v16.20.0">
		<img src="https://img.shields.io/badge/Nodejs%20Support-16.x-brightgreen.svg?style=flat-square" alt="Nodejs Support v16.x">
	</a>
  <img alt="size" src="https://img.shields.io/github/repo-size/ntkhang03/Goat-Bot-V2.svg?style=flat-square&label=size">
  <img alt="code-version" src="https://img.shields.io/badge/dynamic/json?color=brightgreen&label=code%20version&prefix=v&query=%24.version&url=https://github.com/ntkhang03/Goat-Bot-V2/raw/main/package.json&style=flat-square">
  <img alt="visitors" src="https://visitor-badge.laobi.icu/badge?style=flat-square&page_id=ntkhang3.Goat-Bot-V2">
  <img alt="size" src="https://img.shields.io/badge/license-MIT-green?style=flat-square&color=brightgreen">
</p>



The original author of this Bot is Ntkhang. This fork is maintained by: MahMUD  

If you find any issues, please report them!


𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤: <a href="https://www.facebook.com/mahmud0x7" style="color: black;">Mah M UD</a></h3></div>

<p align="center"><a href="fb link" target="_blank" rel="noopener noreferrer">
  <img src="https://i.imgur.com/M6xV2Np.jpeg" width="100" style="margin-right: 10px;"></a>
</p>
<h5 align="center">
>🎀 Mah MUD
</h5>


# 📝 **Tutorial**
Tutorial has been uploaded on YouTube
- For mobile phone: https://youtu.be/zJsemXLaRbY?si=f0PE6L4oCGzYBwPn

**Contact me**

<<div style="font-family: Arial, sans-serif; color: black;">
  <h3>- <a href="https://www.facebook.com/mahmud0x7" style="color: black; text-decoration: none;" target="_blank" rel="noopener">MahMUD Facebook</a></h3>
  <h3>- <a href="https://wa.me/8801836298139?text=Hi%20MahMUD%2C%20I%20want%20to%20chat%20with%20you!" style="color: black; text-decoration: none;" target="_blank" rel="noopener">MahMUD WhatsApp</a></h3>
  <h3>- <a href="mahmudx007@gmail.com?subject=Hello%20MahMUD&body=Hi%20MahMUD!" style="color: black; text-decoration: none;">MahMUD Gmail</a></h3>
</div>

 

<img align="center" src="https://i.imgur.com/UM3ekFf.jpeg"/>


🔹ARIYAN MAHMUD

